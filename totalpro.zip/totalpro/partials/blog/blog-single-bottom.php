<div class="single-bottom">
	<?php dynamic_sidebar('bottom_sidebar'); ?>
</div>
<div class="related-custom" style="padding:10px">
	<?php wpex_get_template_part( 'blog_single_related' );?>
</div>