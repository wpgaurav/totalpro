<?php
/**
 * Single related posts
 *
 * This has been deprecated since Total 4.0
 *
 * @package Total WordPress theme
 * @subpackage Partials
 * @version 3.6.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get post series template part
wpex_get_template_part( 'post_series' );